panjang = input('Masukkan Panjang: '); 
lebar = input('Masukkan lebar: ');
LuasPersegiPanjang = panjang * lebar;
KelilingPersegiPanjang = 2 * (panjang + lebar);

disp("luas : " +LuasPersegiPanjang)
disp("keliling : " +KelilingPersegiPanjang)