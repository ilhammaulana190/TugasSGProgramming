sisia = input('Masukkan sisi a : '); 
sisib = input('Masukkan sisi b : '); 
sisic = input('Masukkan sisi c: '); 
sisid = input('Masukkan sisi d: ');
Kelilinglayang= sisia + sisib + sisic + sisid;

disp("keliling : " +Kelilinglayang)

diagonal1 = input('Masukkan diagonal 1 : ');
diagonal2 = input('Masukkan diagonal 2 : ');
Luaslayang= (diagonal1 * diagonal2) / 2;
disp("luas : " +Luaslayang)