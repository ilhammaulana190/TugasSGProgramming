sisibawah = input('Masukkan sisi bawah : '); 
sisiatas = input('Masukkan sisi atas : '); 
sisikanan = input('Masukkan sisi kanan: '); 
sisikiri = input('Masukkan sisi kiri: ');
Kelilingtrapesium = sisibawah + sisiatas + sisikiri + sisikanan;

disp("keliling : " +Kelilingtrapesium)
tinggi = input('Masukkan tinggi : ');
Luastrapesium = (sisibawah + sisiatas) * tinggi / 2;
disp("luas : " +Luastrapesium)