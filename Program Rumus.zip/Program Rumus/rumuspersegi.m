sisi = input('Masukkan sisi: '); 
LuasPersegi = sisi * sisi;
KelilingPersegi = 4 * sisi;

disp("luas : " +LuasPersegi)
disp("keliling : " +KelilingPersegi)